import React from 'react';
import { AllStats } from '../types';

interface StatsDashboardProps {
  stats: AllStats;
  onReset: () => void;
}

const StatsDashboard: React.FC<StatsDashboardProps> = ({ stats, onReset }) => {
  const subjects = Object.keys(stats);
  const totalScore = subjects.reduce((acc, subject) => acc + (stats[subject]?.score || 0), 0);

  if (subjects.length === 0) {
    return null;
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 gap-4">
        <h2 className="text-xl font-bold text-gray-800">Sonuçlarım</h2>
        <button
          onClick={onReset}
          className="px-4 py-2 bg-red-500 text-white text-sm font-semibold rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 transition-colors self-start sm:self-center"
        >
          İlerlemeyi Sıfırla
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-100 rounded-t-lg">
            <tr>
              <th scope="col" className="px-6 py-3">Ders</th>
              <th scope="col" className="px-6 py-3 text-center">Çözülen Soru</th>
              <th scope="col" className="px-6 py-3 text-center">Doğru</th>
              <th scope="col" className="px-6 py-3 text-center">Yanlış</th>
              <th scope="col" className="px-6 py-3 text-center">Puan</th>
            </tr>
          </thead>
          <tbody>
            {subjects.map(subject => {
              const { total, correct, incorrect, score } = stats[subject];
              return (
                <tr key={subject} className="bg-white border-b hover:bg-gray-50">
                  <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {subject}
                  </th>
                  <td className="px-6 py-4 text-center">{total}</td>
                  <td className="px-6 py-4 text-center text-green-600 font-semibold">{correct}</td>
                  <td className="px-6 py-4 text-center text-red-600 font-semibold">{incorrect}</td>
                  <td className="px-6 py-4 text-center font-bold text-cyan-700">{score}</td>
                </tr>
              );
            })}
             <tr className="bg-gray-100 font-bold text-gray-800">
                <td className="px-6 py-4 text-right" colSpan={4}>TOPLAM PUAN</td>
                <td className="px-6 py-4 text-center text-cyan-800 text-base">{totalScore}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StatsDashboard;
