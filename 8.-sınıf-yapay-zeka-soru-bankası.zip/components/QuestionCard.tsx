import React, { useState } from 'react';
import { Question } from '../types';

interface QuestionCardProps {
  question: Question;
  index: number;
  onAnswerSubmit: (isCorrect: boolean) => void;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ question, index, onAnswerSubmit }) => {
  const [showAnswer, setShowAnswer] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleOptionClick = (option: string) => {
    if (isAnswered) return;
    setSelectedOption(option);
  };

  const handleShowAnswerClick = () => {
    if (!isAnswered && selectedOption) {
      onAnswerSubmit(selectedOption === question.answer);
      setIsAnswered(true);
    }
    setShowAnswer(!showAnswer);
  };

  const getOptionClasses = (option: string) => {
    // If answer is shown, apply correct/incorrect styling
    if (isAnswered || showAnswer) {
      if (option === question.answer) {
        return 'bg-green-100 text-green-800 ring-2 ring-green-500';
      }
      if (option === selectedOption && option !== question.answer) {
        return 'bg-red-100 text-red-800 ring-2 ring-red-500';
      }
      return 'bg-gray-50 opacity-70';
    }
    
    // If answer is not shown yet, apply selection styling
    return selectedOption === option
      ? 'ring-2 ring-cyan-500 bg-cyan-100'
      : 'hover:bg-gray-100';
  };

  return (
    <div className="bg-white shadow-lg rounded-xl overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 ease-in-out">
      <div className="p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          <span className="text-cyan-600 font-bold mr-2">Soru {index + 1}:</span>
          {question.question}
        </h3>
        <div className="space-y-3">
          {Object.entries(question.options).map(([key, value]) => (
            <div
              key={key}
              onClick={() => handleOptionClick(key)}
              className={`p-3 rounded-lg border border-gray-200 transition-all duration-200 ${isAnswered ? 'cursor-default' : 'cursor-pointer'} ${getOptionClasses(key)}`}
            >
              <span className="font-bold mr-2">{key}:</span>
              <span>{value}</span>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
            <button
                onClick={handleShowAnswerClick}
                disabled={!selectedOption}
                className="px-6 py-2 bg-cyan-600 text-white font-semibold rounded-lg hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-50 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
                {showAnswer ? 'Cevabı Gizle' : 'Cevabı Göster'}
            </button>
        </div>
        <div className={`transition-all duration-500 ease-in-out overflow-hidden ${showAnswer ? 'max-h-96 opacity-100 mt-4' : 'max-h-0 opacity-0'}`}>
            <div className="p-4 bg-gray-50 border-l-4 border-cyan-500 rounded-r-lg">
                <p className="font-bold text-green-700">Doğru Cevap: {question.answer}</p>
                <p className="text-gray-700 mt-2">
                <span className="font-semibold">Açıklama:</span> {question.explanation}
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;
