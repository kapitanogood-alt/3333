import { GoogleGenAI, Type } from "@google/genai";
import { Question } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateQuestions = async (
  subject: string,
  unit: string,
  count: number,
  difficulty: string
): Promise<Question[]> => {
  const prompt = `
    8. sınıf, 1. dönem Türkiye müfredatına uygun, "${subject}" dersinin "${unit}" ünitesiyle ilgili, zorluk seviyesi "${difficulty}" olan ${count} adet çoktan seçmeli soru oluştur.
    Sorular, öğrencilerin konuyu anlama ve analiz etme becerilerini ölçmelidir. 
    Her sorunun 4 seçeneği (A, B, C, D), bir doğru cevabı ve doğru cevabın neden doğru olduğuna dair kısa bir açıklaması olmalıdır.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING, description: "Sorunun metni." },
              options: {
                type: Type.OBJECT,
                properties: {
                  A: { type: Type.STRING },
                  B: { type: Type.STRING },
                  C: { type: Type.STRING },
                  D: { type: Type.STRING },
                },
                required: ["A", "B", "C", "D"],
              },
              answer: { type: Type.STRING, description: "Doğru seçeneğin harfi (A, B, C, veya D)." },
              explanation: { type: Type.STRING, description: "Doğru cevabın kısa açıklaması." },
            },
            required: ["question", "options", "answer", "explanation"],
          },
        },
      },
    });

    const jsonText = response.text;
    const questions = JSON.parse(jsonText);
    
    // Validate that the response is an array
    if (!Array.isArray(questions)) {
        throw new Error("API response is not in the expected array format.");
    }
    
    return questions as Question[];
  } catch (error) {
    console.error("Error generating questions:", error);
    throw new Error("Yapay zeka ile soru üretilirken bir hata oluştu. Lütfen tekrar deneyin.");
  }
};